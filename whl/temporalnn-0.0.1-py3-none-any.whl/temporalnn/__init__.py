"""Initialize for temporal-nn modules."""
