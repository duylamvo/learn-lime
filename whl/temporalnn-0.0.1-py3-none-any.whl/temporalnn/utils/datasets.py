"""Datasets endpoint for temporal data."""
import urllib
import os
import logging

logger = logging.getLogger("root")

# ! Some examples data set for time series
Univariate = {
    "shampoo_sales": "https://raw.githubusercontent.com/jbrownlee/Datasets/master/shampoo.csv",
    "temperature": "https://raw.githubusercontent.com/jbrownlee/Datasets/master/daily-min-temperatures.csv",
    "sunspots": "https://raw.githubusercontent.com/jbrownlee/Datasets/master/monthly-sunspots.csv",
    "female_births": "https://raw.githubusercontent.com/jbrownlee/Datasets/master/daily-total-female-births.csv",
    "airline_passengers": "https://raw.githubusercontent.com/jbrownlee/Datasets/master/airline-passengers.csv",
}
Multivariate = {
    "wikipedia_edits": "https://perso.telecom-paristech.fr/eagan/class/igr204/data/smallwikipedia.csv",
    "cause_of_death": "https://perso.telecom-paristech.fr/eagan/class/igr204/data/CausesOfDeath_France_2001-2008.csv",
    "stock_market": "https://datahub.io/core/s-and-p-500-companies-financials/r/0.csv"
}
References = {
    "paristech": "https://perso.telecom-paristech.fr/eagan/class/igr204/datasets",
    "uci": "http://archive.ics.uci.edu/ml/",
    "eeg_eye_state": "http://archive.ics.uci.edu/ml/datasets/EEG+Eye+State",
    "occupancy_detection": "http://archive.ics.uci.edu/ml/datasets/Occupancy+Detection+",
    "ozone_level_detection": "http://archive.ics.uci.edu/ml/datasets/Ozone+Level+Detection",
    "datahub.io": "https://datahub.io/collections/stock-market-data",
}


def download_dataset(url, save_to="downloads"):
    """Download the data set with url.

    :param save_to: folder the file will be saved to
    :return: path to the dataset file
    """

    file_name = url.split("/")[-1]
    f_path = f"{save_to}/{file_name}"

    try:
        os.makedirs(f"./{save_to}")
        logger.info(f"created folder {save_to}")
    except FileExistsError:
        pass
    urllib.request.urlretrieve(url, f_path)

    return f_path
